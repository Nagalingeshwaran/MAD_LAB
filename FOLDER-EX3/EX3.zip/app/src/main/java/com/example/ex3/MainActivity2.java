package com.example.ex3;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        String shape = getIntent().getStringExtra("shape");


        Bitmap bg = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888);
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setImageBitmap(bg);

        Canvas canvas = new Canvas(bg);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);

        if (shape != null && shape.equals("Rectangle")) {
            paint.setColor(Color.RED);
            paint.setTextSize(40);
            canvas.drawText("Rectangle", 250, 200, paint);
            canvas.drawRect(200, 250, 520, 400, paint);

        } else if (shape != null && shape.equals("CIRCLE")) {
            paint.setColor(Color.DKGRAY);
            paint.setTextSize(40);
            canvas.drawText("Circle", 311, 450, paint);
            canvas.drawCircle(360, 700, 200, paint);

        }else if (shape != null && shape.equals("House")) {
            drawHouse(canvas,paint);
        }
        else if (shape.equals("Triangle")) {
            paint.setColor(Color.CYAN);
            Path path = new Path();
            path.moveTo(400, 200);
            path.lineTo(200, 500);
            path.lineTo(600, 500);
            path.close();
            canvas.drawPath(path, paint);
        }

        else {
            paint.setColor(Color.BLUE);
            paint.setTextSize(40);
            canvas.drawText("No Shape Selected", 200, 600, paint);
        }
    }
    private void drawHouse(Canvas c, Paint p) {

        // House body
        c.drawRect(250, 350, 550, 600, p);


        Paint roofPaint = new Paint();
        roofPaint.setColor(Color.RED);
        roofPaint.setStyle(Paint.Style.FILL);
        roofPaint.setAntiAlias(true);

        Path roofPath = new Path();
        roofPath.moveTo(400, 250);
        roofPath.lineTo(220, 350);
        roofPath.lineTo(580, 350);
        roofPath.close();

        c.drawPath(roofPath, roofPaint);


        Paint doorPaint = new Paint();
        doorPaint.setColor(Color.WHITE);
        doorPaint.setStyle(Paint.Style.FILL);

        c.drawRect(370, 450, 430, 600, doorPaint);
    }
}






