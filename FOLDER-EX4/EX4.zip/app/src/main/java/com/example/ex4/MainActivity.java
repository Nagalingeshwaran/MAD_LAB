package com.example.ex4;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText movieId, etMovie, etDirector;
    Button btnInsert, btnUpdate, btnShow, btnDelete;
    TableLayout tableLayout;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize EditTexts
        movieId = findViewById(R.id.movieId);
        etMovie = findViewById(R.id.etMovie);
        etDirector = findViewById(R.id.etDirector);

        // Initialize Buttons
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnShow = findViewById(R.id.btnShow);
        btnDelete = findViewById(R.id.btnDelete);

        // Initialize TableLayout
        tableLayout = findViewById(R.id.tableLayout);

        // Create/Open database
        db = openOrCreateDatabase("MovieDB", Context.MODE_PRIVATE, null);
        db.execSQL("DROP TABLE IF EXISTS Details");
        db.execSQL("CREATE TABLE Details(id TEXT PRIMARY KEY, title TEXT, director TEXT)");

        // INSERT button
        btnInsert.setOnClickListener(v -> {
            String id = movieId.getText().toString().trim();
            String title = etMovie.getText().toString().trim();
            String director = etDirector.getText().toString().trim();

            if (id.isEmpty() || title.isEmpty()) {
                Toast.makeText(this, "Enter Movie ID and Name", Toast.LENGTH_SHORT).show();
                return;
            }

            db.execSQL("INSERT OR REPLACE INTO Details VALUES(?,?,?)",
                    new Object[]{id, title, director});
            clear();
            Toast.makeText(this, "Inserted", Toast.LENGTH_SHORT).show();
        });

        // UPDATE button (partial update)
        btnUpdate.setOnClickListener(v -> {
            String id = movieId.getText().toString().trim();
            if (id.isEmpty()) {
                Toast.makeText(this, "Enter Movie ID to update", Toast.LENGTH_SHORT).show();
                return;
            }

            Cursor c = db.rawQuery("SELECT * FROM Details WHERE id=?", new String[]{id});
            if (c.moveToFirst()) {
                String currentTitle = c.getString(1);
                String currentDirector = c.getString(2);
                c.close();

                String newTitle = etMovie.getText().toString().trim();
                String newDirector = etDirector.getText().toString().trim();

                if (!newTitle.isEmpty()) currentTitle = newTitle;
                if (!newDirector.isEmpty()) currentDirector = newDirector;

                db.execSQL("UPDATE Details SET title=?, director=? WHERE id=?",
                        new Object[]{currentTitle, currentDirector, id});
                Toast.makeText(this, "Updated successfully", Toast.LENGTH_SHORT).show();
                clear();
            } else {
                c.close();
                Toast.makeText(this, "Movie not found", Toast.LENGTH_SHORT).show();
            }
        });

        // DELETE button
        btnDelete.setOnClickListener(v -> {
            String id = movieId.getText().toString().trim();
            if (id.isEmpty()) {
                Toast.makeText(this, "Enter Movie ID to delete", Toast.LENGTH_SHORT).show();
                return;
            }
            db.execSQL("DELETE FROM Details WHERE id=?", new Object[]{id});
            clear();
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
        });

        // SHOW button
        btnShow.setOnClickListener(v -> showTable());
    }

    // Display table
    private void showTable() {
        tableLayout.removeAllViews();

        // Header row
        TableRow header = new TableRow(this);
        header.setBackgroundColor(Color.DKGRAY);
        header.addView(makeText("ID", true));
        header.addView(makeText("Title", true));
        header.addView(makeText("Director", true));
        tableLayout.addView(header);

        // Data rows
        Cursor c = db.rawQuery("SELECT * FROM Details", null);
        if (c.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);
                row.addView(makeText(c.getString(0), false));
                row.addView(makeText(c.getString(1), false));
                row.addView(makeText(c.getString(2), false));
                tableLayout.addView(row);
            } while (c.moveToNext());
        }
        c.close();
    }

    // Helper for TableLayout TextViews
    private TextView makeText(String s, boolean isHeader) {
        TextView t = new TextView(this);
        t.setText(s != null ? s : "");
        t.setTextSize(isHeader ? 36 : 28);
        t.setPadding(18, 18, 18, 18);
        if (isHeader) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    // Clear input fields
    private void clear() {
        movieId.setText("");
        etMovie.setText("");
        etDirector.setText("");
    }
}